#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    // 设置应用程序信息
    QApplication::setApplicationName("VideoStreamClient");
    QApplication::setOrganizationName("MyCompany");

    MainWindow window;
    window.show();

    return app.exec();
}
