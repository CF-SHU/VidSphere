#include "videowidget.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QMouseEvent>
#include <QPainter>
#include <QStyleOption>

VideoWidget::VideoWidget(const QString &title, const QString &author, const QString &thumbnailUrl, QWidget *parent)
    : QWidget(parent)
    , m_title(title)
    , m_author("UP主: " + author)
    , m_thumbnailUrl(thumbnailUrl)
    , m_thumbnailLoaded(false)
{
    setFixedSize(200, 250); // 设置固定大小
    setStyleSheet("VideoWidget { background-color: #ffffff; border: 1px solid #e0e0e0; border-radius: 8px; }"
                  "VideoWidget:hover { background-color: #f5f5f5; border: 1px solid #cccccc; }");
    
    // 创建布局
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(8, 8, 8, 8);
    mainLayout->setSpacing(8);
    
    // 缩略图标签
    m_thumbnailLabel = new QLabel(this);
    m_thumbnailLabel->setFixedSize(184, 140); // 留出边距
    m_thumbnailLabel->setStyleSheet("QLabel { background-color: #f0f0f0; border-radius: 4px; }");
    m_thumbnailLabel->setAlignment(Qt::AlignCenter);
    
    // 如果有缩略图URL，加载缩略图
    if (!thumbnailUrl.isEmpty()) {
        setThumbnail(thumbnailUrl);
    } else {
        // 设置默认缩略图
        m_thumbnailLabel->setText("视频缩略图");
        m_thumbnailLabel->setStyleSheet("QLabel { background-color: #f0f0f0; border-radius: 4px; color: #999999; font-size: 14px; }");
    }
    
    // 标题标签
    m_titleLabel = new QLabel(title, this);
    m_titleLabel->setWordWrap(true);
    m_titleLabel->setStyleSheet("QLabel { color: #333333; font-size: 14px; font-weight: bold; }");
    m_titleLabel->setMaximumHeight(40);
    
    // 作者标签
    m_authorLabel = new QLabel(m_author, this);
    m_authorLabel->setStyleSheet("QLabel { color: #666666; font-size: 12px; }");
    
    // 添加到布局
    mainLayout->addWidget(m_thumbnailLabel);
    mainLayout->addWidget(m_titleLabel);
    mainLayout->addWidget(m_authorLabel);
    
    // 添加间距使布局更美观
    mainLayout->addStretch();
}

void VideoWidget::setTitle(const QString &title)
{
    m_title = title;
    m_titleLabel->setText(title);
}

void VideoWidget::setAuthor(const QString &author)
{
    m_author = "UP主: " + author;
    m_authorLabel->setText(m_author);
}

void VideoWidget::setThumbnail(const QString &thumbnailUrl)
{
    m_thumbnailUrl = thumbnailUrl;
    
    m_thumbnailLabel->setText("加载中...");
    m_thumbnailLabel->setStyleSheet("QLabel { background-color: #f0f0f0; border-radius: 4px; color: #999999; font-size: 12px; }");
    
    QPixmap placeholder(184, 140);
    placeholder.fill(Qt::lightGray);
    QPainter painter(&placeholder);
    painter.setPen(QPen(Qt::darkGray, 2));
    painter.drawRect(0, 0, 183, 139);
    painter.drawText(placeholder.rect(), Qt::AlignCenter, "视频缩略图");
    
    m_thumbnailPixmap = placeholder;
    m_thumbnailLabel->setPixmap(m_thumbnailPixmap.scaled(184, 140, Qt::KeepAspectRatio, Qt::SmoothTransformation));
    m_thumbnailLoaded = true;
}

void VideoWidget::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        emit clicked();
    }
    QWidget::mousePressEvent(event);
}

void VideoWidget::paintEvent(QPaintEvent *event)
{
    QStyleOption opt;
    opt.initFrom(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);
    QWidget::paintEvent(event);
}
