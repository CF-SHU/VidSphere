#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "videowidget.h"
#include <QMessageBox>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QUrl>
#include <QListWidgetItem>
#include <QProgressBar>
#include <QSlider>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QGroupBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QScrollArea>
#include <QGridLayout>
#include <QStackedWidget>
#include <QToolButton>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , networkManager(new QNetworkAccessManager(this))
    , mediaPlayer(new QMediaPlayer(this))
    , videoWidget(new QVideoWidget)
    , audioOutput(new QAudioOutput(this))
    , mainStackedWidget(nullptr)
    , videoListWidget(nullptr)
    , videoPlayerWidget(nullptr)
    , videoListContentWidget(nullptr)
    , videoListScrollArea(nullptr)
    , videoListLayout(nullptr)
    , returnButton(nullptr)
{
    ui->setupUi(this);

    // 设置窗口属性
    setWindowTitle("视频流客户端");
    resize(1000, 700);

    // 初始化界面
    setupUI();
    setupConnections();

    // 初始化媒体播放器
    mediaPlayer->setVideoOutput(videoWidget);
    mediaPlayer->setAudioOutput(audioOutput);

    // 设置默认服务器地址
    ui->serverInput->setText("http://location:5000");

    // 禁用控制按钮（等待连接）
    ui->playButton->setEnabled(false);
    ui->pauseButton->setEnabled(false);
    ui->stopButton->setEnabled(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setupUI()
{
    // 创建主堆叠窗口部件
    mainStackedWidget = new QStackedWidget(this);
    
    // 创建视频列表界面
    setupVideoListUI();
    
    // 创建视频播放界面
    setupVideoPlayerUI();
    
    // 添加界面到堆叠部件
    mainStackedWidget->addWidget(videoListWidget);  // 索引 0
    mainStackedWidget->addWidget(videoPlayerWidget); // 索引 1
    
    // 设置主窗口中心部件
    setCentralWidget(mainStackedWidget);
    
    // 默认显示视频列表界面
    showVideoList();
}

void MainWindow::setupVideoListUI()
{
    // 创建视频列表界面
    videoListWidget = new QWidget(this);
    QVBoxLayout *listLayout = new QVBoxLayout(videoListWidget);
    
    // 服务器连接区域
    QGroupBox *serverGroup = new QGroupBox("服务器连接", this);
    QHBoxLayout *serverLayout = new QHBoxLayout(serverGroup);
    
    QLabel *serverLabel = new QLabel("服务器地址:", this);
    ui->serverInput = new QLineEdit(this);
    ui->connectButton = new QPushButton("连接", this);
    
    serverLayout->addWidget(serverLabel);
    serverLayout->addWidget(ui->serverInput);
    serverLayout->addWidget(ui->connectButton);
    serverLayout->addStretch();
    
    // 添加服务器连接区域到布局
    listLayout->addWidget(serverGroup);
    
    // 创建滚动区域用于视频列表
    videoListScrollArea = new QScrollArea(this);
    videoListScrollArea->setWidgetResizable(true);
    videoListScrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    videoListScrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    
    // 创建视频列表内容部件
    videoListContentWidget = new QWidget(videoListScrollArea);
    videoListLayout = new QGridLayout(videoListContentWidget);
    videoListLayout->setAlignment(Qt::AlignTop | Qt::AlignLeft);
    videoListLayout->setHorizontalSpacing(20);
    videoListLayout->setVerticalSpacing(20);
    videoListLayout->setContentsMargins(20, 20, 20, 20);
    
    // 设置滚动区域的部件
    videoListScrollArea->setWidget(videoListContentWidget);
    
    // 添加滚动区域到主布局
    listLayout->addWidget(videoListScrollArea);
    
    // 添加状态栏
    QHBoxLayout *statusLayout = new QHBoxLayout();
    
    ui->statusLabel = new QLabel("准备连接服务器...", this);
    ui->progressBar = new QProgressBar(this);
    
    statusLayout->addWidget(ui->statusLabel);
    statusLayout->addWidget(ui->progressBar);
    
    listLayout->addLayout(statusLayout);
}

void MainWindow::setupVideoPlayerUI()
{
    // 创建视频播放界面
    videoPlayerWidget = new QWidget(this);
    QVBoxLayout *playerLayout = new QVBoxLayout(videoPlayerWidget);
    
    // 创建返回按钮
    returnButton = new QToolButton(this);
    returnButton->setText("← 返回");
    returnButton->setStyleSheet("QToolButton { padding: 8px 16px; font-size: 14px; } QToolButton:hover { background-color: #f0f0f0; } QToolButton:pressed { background-color: #d0d0d0; }");
    
    // 添加返回按钮到布局
    playerLayout->addWidget(returnButton, 0, Qt::AlignLeft | Qt::AlignTop);
    
    // 添加视频显示部件
    playerLayout->addWidget(videoWidget);
    
    // 播放控制区域
    QHBoxLayout *controlLayout = new QHBoxLayout();
    
    ui->playButton = new QPushButton("播放", this);
    ui->pauseButton = new QPushButton("暂停", this);
    ui->stopButton = new QPushButton("停止", this);
    
    QLabel *volumeLabel = new QLabel("音量:", this);
    ui->volumeSlider = new QSlider(Qt::Horizontal, this);
    ui->volumeSlider->setRange(0, 100);
    ui->volumeSlider->setValue(50);
    
    controlLayout->addWidget(ui->playButton);
    controlLayout->addWidget(ui->pauseButton);
    controlLayout->addWidget(ui->stopButton);
    controlLayout->addSpacing(20);
    controlLayout->addWidget(volumeLabel);
    controlLayout->addWidget(ui->volumeSlider);
    controlLayout->addStretch();
    
    playerLayout->addLayout(controlLayout);
    
    // 添加状态栏
    QHBoxLayout *statusLayout = new QHBoxLayout();
    
    ui->statusLabel = new QLabel("准备连接服务器...", this);
    ui->progressBar = new QProgressBar(this);
    
    statusLayout->addWidget(ui->statusLabel);
    statusLayout->addWidget(ui->progressBar);
    
    playerLayout->addLayout(statusLayout);
}

void MainWindow::setupConnections()
{
    // 连接按钮信号
    connect(ui->connectButton, &QPushButton::clicked, this, &MainWindow::onConnectClicked);

    // 播放控制信号
    connect(ui->playButton, &QPushButton::clicked, this, &MainWindow::onPlayClicked);
    connect(ui->pauseButton, &QPushButton::clicked, this, &MainWindow::onPauseClicked);
    connect(ui->stopButton, &QPushButton::clicked, this, &MainWindow::onStopClicked);

    // 音量控制信号
    connect(ui->volumeSlider, &QSlider::valueChanged, this, &MainWindow::onVolumeChanged);
    
    // 返回按钮信号
    connect(returnButton, &QToolButton::clicked, this, &MainWindow::onReturnToListClicked);

    // 网络请求信号
    connect(networkManager, &QNetworkAccessManager::finished, this, &MainWindow::onVideoListReceived);

    // 媒体播放器信号
    connect(mediaPlayer, &QMediaPlayer::mediaStatusChanged, this, [=](QMediaPlayer::MediaStatus status) {
        switch (status) {
        case QMediaPlayer::LoadingMedia:
            ui->statusLabel->setText("正在加载媒体...");
            break;
        case QMediaPlayer::LoadedMedia:
            ui->statusLabel->setText("媒体加载完成");
            break;
        case QMediaPlayer::BufferingMedia:
            ui->statusLabel->setText("正在缓冲...");
            break;
        case QMediaPlayer::BufferedMedia:
            ui->statusLabel->setText("缓冲完成");
            break;
        default:
            break;
        }
    });

    connect(mediaPlayer, &QMediaPlayer::positionChanged, this, [=](qint64 position) {
        if (mediaPlayer->duration() > 0) {
            int progress = (position * 100) / mediaPlayer->duration();
            ui->progressBar->setValue(progress);
        }
    });
}

void MainWindow::onConnectClicked()
{
    serverAddress = ui->serverInput->text().trimmed();

    if (serverAddress.isEmpty()) {
        QMessageBox::warning(this, "警告", "请输入服务器地址");
        return;
    }

    // 更新状态
    ui->statusLabel->setText("正在连接到服务器...");
    clearVideoList();
    videoList.clear();
    videoDetails.clear();

    // 获取视频列表
    loadVideoList();
}

void MainWindow::showVideoList()
{
    mainStackedWidget->setCurrentIndex(0); // 显示视频列表界面
}

void MainWindow::showVideoPlayer()
{
    mainStackedWidget->setCurrentIndex(1); // 显示视频播放界面
}

void MainWindow::clearVideoList()
{
    // 删除所有视频小部件
    QLayoutItem *child;
    while ((child = videoListLayout->takeAt(0)) != nullptr) {
        delete child->widget();
        delete child;
    }
}

void MainWindow::onReturnToListClicked()
{
    showVideoList();
    ui->statusLabel->setText("已返回视频列表");
}

void MainWindow::loadVideoList()
{
    QUrl url(serverAddress + "/videos");
    QNetworkRequest request(url);

    // 设置请求头
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    // 发送 GET 请求
    networkManager->get(request);
}

void MainWindow::onVideoListReceived(QNetworkReply *reply)
{
    if (reply->error() != QNetworkReply::NoError) {
        ui->statusLabel->setText("连接服务器失败: " + reply->errorString());
        QMessageBox::critical(this, "错误", "无法连接到服务器:\n" + reply->errorString());
        reply->deleteLater();
        return;
    }

    // 读取响应数据
    QByteArray responseData = reply->readAll();
    reply->deleteLater();

    // 解析 JSON
    QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
    if (!jsonDoc.isObject()) {
        ui->statusLabel->setText("服务器响应格式错误");
        return;
    }

    QJsonObject jsonObj = jsonDoc.object();
    if (!jsonObj.contains("videos") || !jsonObj["videos"].isArray()) {
        ui->statusLabel->setText("未找到视频列表");
        return;
    }

    QJsonArray videosArray = jsonObj["videos"].toArray();
    clearVideoList();
    videoList.clear();
    videoDetails.clear();

    // 添加到网格布局
    int row = 0, col = 0;
    const int maxCols = 4; // 每行最多4个视频项

    for (int i = 0; i < videosArray.size(); ++i) {
        QJsonValue value = videosArray[i];
        if (value.isObject()) {
            QJsonObject videoObj = value.toObject();
            QString name = videoObj["name"].toString();
            QString url = videoObj["url"].toString();
            QString author = videoObj["author"].toString(); // 假设服务器也返回作者信息
            QString thumbnail = videoObj["thumbnail"].toString(); // 假设服务器返回缩略图URL

            if (!name.isEmpty() && !url.isEmpty()) {
                // 添加到视频列表
                videoList.append(qMakePair(name, url));
                videoDetails.append(qMakePair(name, author));

                // 创建自定义视频小部件
                VideoWidget *videoWidgetItem = new VideoWidget(name, author, thumbnail, this);
                
                // 连接点击信号
                connect(videoWidgetItem, &VideoWidget::clicked, this, [this, i]() {
                    onVideoSelected(i);
                });
                
                // 添加到网格布局
                videoListLayout->addWidget(videoWidgetItem, row, col);
                
                // 更新行列索引
                col++;
                if (col >= maxCols) {
                    col = 0;
                    row++;
                }
            }
        }
    }

    if (videoList.isEmpty()) {
        ui->statusLabel->setText("服务器上没有找到视频");
    } else {
        ui->statusLabel->setText(QString("找到 %1 个视频").arg(videoList.size()));
    }
}

void MainWindow::onVideoSelected(int index)
{
    if (index < 0 || index >= videoList.size()) { return; }

    // 获取选择的视频 URL
    QString videoUrl = serverAddress + videoList[index].second;

    // 设置媒体源
    mediaPlayer->setSource(QUrl(videoUrl));

    // 启用控制按钮
    ui->playButton->setEnabled(true);
    ui->pauseButton->setEnabled(true);
    ui->stopButton->setEnabled(true);

    ui->statusLabel->setText("已选择: " + videoList[index].first);
    
    // 显示视频播放界面
    showVideoPlayer();
}

void MainWindow::onPlayClicked()
{
    mediaPlayer->play();
    ui->statusLabel->setText("正在播放...");
}

void MainWindow::onPauseClicked()
{
    mediaPlayer->pause();
    ui->statusLabel->setText("已暂停");
}

void MainWindow::onStopClicked()
{
    mediaPlayer->stop();
    ui->statusLabel->setText("已停止");
    ui->progressBar->setValue(0);
}

void MainWindow::onVolumeChanged(int value)
{
    // 设置音量 (0-100 转换为 0.0-1.0)
    audioOutput->setVolume(value / 100.0);
}
