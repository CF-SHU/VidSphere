#pragma once

#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMouseEvent>
#include <QPixmap>
#include <QPainter>

class VideoWidget : public QWidget
{
    Q_OBJECT

public:
    explicit VideoWidget(const QString &title = "", const QString &author = "", const QString &thumbnailUrl = "", QWidget *parent = nullptr);
    
    void setTitle(const QString &title);
    void setAuthor(const QString &author);
    void setThumbnail(const QString &thumbnailUrl);
    
    QString getTitle() const { return m_title; }
    QString getAuthor() const { return m_author; }
    QString getThumbnailUrl() const { return m_thumbnailUrl; }

signals:
    void clicked();

protected:
    void mousePressEvent(QMouseEvent *event) override;
    void paintEvent(QPaintEvent *event) override;

private:
    QString m_title;
    QString m_author;
    QString m_thumbnailUrl;
    QPixmap m_thumbnailPixmap;
    QLabel *m_thumbnailLabel;
    QLabel *m_titleLabel;
    QLabel *m_authorLabel;
    bool m_thumbnailLoaded;
};
