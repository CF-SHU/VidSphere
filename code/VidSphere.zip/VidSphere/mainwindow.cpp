#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QMessageBox>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QUrl>
#include <QListWidgetItem>
#include <QProgressBar>
#include <QSlider>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QGroupBox>
#include <QVBoxLayout>
#include <QHBoxLayout>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , networkManager(new QNetworkAccessManager(this))
    , mediaPlayer(new QMediaPlayer(this))
    , videoWidget(new QVideoWidget)
    , audioOutput(new QAudioOutput(this))
{
    ui->setupUi(this);

    // 设置窗口属性
    setWindowTitle("视频流客户端");
    resize(1000, 700);

    // 初始化界面
    setupUI();
    setupConnections();

    // 初始化媒体播放器
    mediaPlayer->setVideoOutput(videoWidget);
    mediaPlayer->setAudioOutput(audioOutput);

    // 设置默认服务器地址
    ui->serverInput->setText("http://localhost:5000");

    // 禁用控制按钮（等待连接）
    ui->playButton->setEnabled(false);
    ui->pauseButton->setEnabled(false);
    ui->stopButton->setEnabled(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setupUI()
{
    // 创建中央部件和布局
    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);

    // 服务器连接区域
    QGroupBox *serverGroup = new QGroupBox("服务器连接", this);
    QHBoxLayout *serverLayout = new QHBoxLayout(serverGroup);

    QLabel *serverLabel = new QLabel("服务器地址:", this);
    ui->serverInput = new QLineEdit(this);
    ui->connectButton = new QPushButton("连接", this);

    serverLayout->addWidget(serverLabel);
    serverLayout->addWidget(ui->serverInput);
    serverLayout->addWidget(ui->connectButton);
    serverLayout->addStretch();

    // 视频列表区域
    QGroupBox *videoListGroup = new QGroupBox("视频列表", this);
    QVBoxLayout *videoListLayout = new QVBoxLayout(videoListGroup);

    ui->videoListWidget = new QListWidget(this);
    videoListLayout->addWidget(ui->videoListWidget);

    // 视频播放区域
    QGroupBox *videoGroup = new QGroupBox("视频播放器", this);
    QVBoxLayout *videoLayout = new QVBoxLayout(videoGroup);

    // 添加视频显示部件
    videoLayout->addWidget(videoWidget);

    // 播放控制区域
    QHBoxLayout *controlLayout = new QHBoxLayout();

    ui->playButton = new QPushButton("播放", this);
    ui->pauseButton = new QPushButton("暂停", this);
    ui->stopButton = new QPushButton("停止", this);

    QLabel *volumeLabel = new QLabel("音量:", this);
    ui->volumeSlider = new QSlider(Qt::Horizontal, this);
    ui->volumeSlider->setRange(0, 100);
    ui->volumeSlider->setValue(50);

    ui->statusLabel = new QLabel("准备连接服务器...", this);
    ui->progressBar = new QProgressBar(this);

    controlLayout->addWidget(ui->playButton);
    controlLayout->addWidget(ui->pauseButton);
    controlLayout->addWidget(ui->stopButton);
    controlLayout->addSpacing(20);
    controlLayout->addWidget(volumeLabel);
    controlLayout->addWidget(ui->volumeSlider);
    controlLayout->addStretch();

    // 添加所有部件到主布局
    mainLayout->addWidget(serverGroup);
    mainLayout->addWidget(videoListGroup, 1);
    mainLayout->addWidget(videoGroup, 2);
    mainLayout->addLayout(controlLayout);
    mainLayout->addWidget(ui->progressBar);
    mainLayout->addWidget(ui->statusLabel);

    setCentralWidget(centralWidget);
}

void MainWindow::setupConnections()
{
    // 连接按钮信号
    connect(ui->connectButton, &QPushButton::clicked, this, &MainWindow::onConnectClicked);
    connect(ui->videoListWidget, &QListWidget::itemDoubleClicked, this, &MainWindow::onVideoSelected);

    // 播放控制信号
    connect(ui->playButton, &QPushButton::clicked, this, &MainWindow::onPlayClicked);
    connect(ui->pauseButton, &QPushButton::clicked, this, &MainWindow::onPauseClicked);
    connect(ui->stopButton, &QPushButton::clicked, this, &MainWindow::onStopClicked);

    // 音量控制信号
    connect(ui->volumeSlider, &QSlider::valueChanged, this, &MainWindow::onVolumeChanged);

    // 网络请求信号
    connect(networkManager, &QNetworkAccessManager::finished, this, &MainWindow::onVideoListReceived);

    // 媒体播放器信号
    connect(mediaPlayer, &QMediaPlayer::mediaStatusChanged, this, [=](QMediaPlayer::MediaStatus status) {
        switch (status) {
        case QMediaPlayer::LoadingMedia:
            ui->statusLabel->setText("正在加载媒体...");
            break;
        case QMediaPlayer::LoadedMedia:
            ui->statusLabel->setText("媒体加载完成");
            break;
        case QMediaPlayer::BufferingMedia:
            ui->statusLabel->setText("正在缓冲...");
            break;
        case QMediaPlayer::BufferedMedia:
            ui->statusLabel->setText("缓冲完成");
            break;
        default:
            break;
        }
    });

    connect(mediaPlayer, &QMediaPlayer::positionChanged, this, [=](qint64 position) {
        if (mediaPlayer->duration() > 0) {
            int progress = (position * 100) / mediaPlayer->duration();
            ui->progressBar->setValue(progress);
        }
    });
}

void MainWindow::onConnectClicked()
{
    serverAddress = ui->serverInput->text().trimmed();

    if (serverAddress.isEmpty()) {
        QMessageBox::warning(this, "警告", "请输入服务器地址");
        return;
    }

    // 更新状态
    ui->statusLabel->setText("正在连接到服务器...");
    ui->videoListWidget->clear();
    videoList.clear();

    // 获取视频列表
    loadVideoList();
}

void MainWindow::loadVideoList()
{
    QUrl url(serverAddress + "/videos");
    QNetworkRequest request(url);

    // 设置请求头
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    // 发送 GET 请求
    networkManager->get(request);
}

void MainWindow::onVideoListReceived(QNetworkReply *reply)
{
    if (reply->error() != QNetworkReply::NoError) {
        ui->statusLabel->setText("连接服务器失败: " + reply->errorString());
        QMessageBox::critical(this, "错误", "无法连接到服务器:\n" + reply->errorString());
        reply->deleteLater();
        return;
    }

    // 读取响应数据
    QByteArray responseData = reply->readAll();
    reply->deleteLater();

    // 解析 JSON
    QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
    if (!jsonDoc.isObject()) {
        ui->statusLabel->setText("服务器响应格式错误");
        return;
    }

    QJsonObject jsonObj = jsonDoc.object();
    if (!jsonObj.contains("videos") || !jsonObj["videos"].isArray()) {
        ui->statusLabel->setText("未找到视频列表");
        return;
    }

    QJsonArray videosArray = jsonObj["videos"].toArray();
    ui->videoListWidget->clear();
    videoList.clear();

    // 添加到列表
    for (const QJsonValue &value : videosArray) {
        if (value.isObject()) {
            QJsonObject videoObj = value.toObject();
            QString name = videoObj["name"].toString();
            QString url = videoObj["url"].toString();

            if (!name.isEmpty() && !url.isEmpty()) {
                videoList.append(qMakePair(name, url));
                ui->videoListWidget->addItem(name);
            }
        }
    }

    if (videoList.isEmpty()) {
        ui->statusLabel->setText("服务器上没有找到视频");
    } else {
        ui->statusLabel->setText(QString("找到 %1 个视频").arg(videoList.size()));
    }
}

void MainWindow::onVideoSelected()
{
    int currentRow = ui->videoListWidget->currentRow();
    if (currentRow < 0 || currentRow >= videoList.size()) { return; }

    // 获取选择的视频 URL
    QString videoUrl = serverAddress + videoList[currentRow].second;

    // 设置媒体源
    mediaPlayer->setSource(QUrl(videoUrl));

    // 启用控制按钮
    ui->playButton->setEnabled(true);
    ui->pauseButton->setEnabled(true);
    ui->stopButton->setEnabled(true);

    ui->statusLabel->setText("已选择: " + videoList[currentRow].first);
}

void MainWindow::onPlayClicked()
{
    mediaPlayer->play();
    ui->statusLabel->setText("正在播放...");
}

void MainWindow::onPauseClicked()
{
    mediaPlayer->pause();
    ui->statusLabel->setText("已暂停");
}

void MainWindow::onStopClicked()
{
    mediaPlayer->stop();
    ui->statusLabel->setText("已停止");
    ui->progressBar->setValue(0);
}

void MainWindow::onVolumeChanged(int value)
{
    // 设置音量 (0-100 转换为 0.0-1.0)
    audioOutput->setVolume(value / 100.0);
}
