#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QMediaPlayer>
#include <QVideoWidget>
#include <QAudioOutput>

QT_BEGIN_NAMESPACE
namespace Ui {
    class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onConnectClicked();                        // 连接服务器
    void onVideoListReceived(QNetworkReply *reply); // 接收视频列表
    void onVideoSelected();                         // 选择视频
    void onPlayClicked();                           // 播放视频
    void onPauseClicked();                          // 暂停视频
    void onStopClicked();                           // 停止视频
    void onVolumeChanged(int value);                // 音量调节

private:
    void setupUI();          // 初始化界面
    void setupConnections(); // 连接信号槽
    void loadVideoList();    // 加载视频列表

    Ui::MainWindow *ui;
    QNetworkAccessManager *networkManager;
    QMediaPlayer *mediaPlayer;
    QVideoWidget *videoWidget;
    QAudioOutput *audioOutput;
    QString serverAddress;                    // 服务器地址
    QList<QPair<QString, QString>> videoList; // 视频列表 (名称, URL)
};
#endif // MAINWINDOW_H
